CREATE TABLE usuarios
(	rut	varchar](15) NOT NULL,
	nombre	varchar](50) NULL,
	apellido	varchar](50) NULL,
	edad	int NULL,
	fecha_nac	datetime] NULL,
	tipo_usuario	varchar](3) NULL
)